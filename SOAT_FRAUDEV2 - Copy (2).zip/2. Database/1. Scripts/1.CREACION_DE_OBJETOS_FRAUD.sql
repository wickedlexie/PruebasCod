/* *************************************************************** */
/*                       CREACI�N ESQUEMAS                         */
/* *************************************************************** */

USE [SIT_MINERIA]
GO

IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'FRAUD') EXEC ('CREATE SCHEMA [FRAUD]')
GO


/* *************************************************************** */
/*               CREACI�N TABLAS ESQUEMA FRAUD                     */
/* *************************************************************** */

/****** Object:  Table [FRAUD].[TBL_MN_PFRAU_ACTCORTE] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[FRAUD].[TBL_MN_PFRAU_ACTCORTE]') AND type in (N'U')) DROP TABLE [FRAUD].[TBL_MN_PFRAU_ACTCORTE]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [FRAUD].[TBL_MN_PFRAU_ACTCORTE](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[TIPO] [varchar](255) NOT NULL,
	[VALOR] [varchar](255) NOT NULL,
	[fecha_creacion] [datetime] NULL
) ON [PRIMARY]
GO

/****** Object:  Table [FRAUD].[TBL_MN_PFRAU_CAMBIOESTADO] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[FRAUD].[TBL_MN_PFRAU_CAMBIOESTADO]') AND type in (N'U')) DROP TABLE [FRAUD].[TBL_MN_PFRAU_CAMBIOESTADO]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [FRAUD].[TBL_MN_PFRAU_CAMBIOESTADO](
	[Observacion] [nvarchar](1000) NULL,
	[Cambio de estad] [nvarchar](255) NULL,
	[NUMERO_SINIESTRO] [nvarchar](255) NULL,
	[NUMERO_RECLAMACION] [nvarchar](255) NULL
) ON [PRIMARY]
GO

/****** Object:  Table [FRAUD].[TBL_MN_PFRAU_CENSO] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[FRAUD].[TBL_MN_PFRAU_CENSO]') AND type in (N'U')) DROP TABLE [FRAUD].[TBL_MN_PFRAU_CENSO]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [FRAUD].[TBL_MN_PFRAU_CENSO](
	[Poliza+Fecha accidente+Cedula] [nvarchar](255) NULL,
	[ID_CASO_IPS] [nvarchar](255) NULL,
	[REGION] [nvarchar](255) NULL,
	[RESULTADO] [nvarchar](255) NULL,
	[FECHA_ENTREGA] [nvarchar](255) NULL,
	[CAUSAL_NO_COBERTURA] [nvarchar](255) NULL
) ON [PRIMARY]
GO


/****** Object:  Table [FRAUD].[TBL_MN_PFRAU_CIUDADES] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[FRAUD].[TBL_MN_PFRAU_CIUDADES]') AND type in (N'U')) DROP TABLE [FRAUD].[TBL_MN_PFRAU_CIUDADES]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [FRAUD].[TBL_MN_PFRAU_CIUDADES](
	[Ciudades] [nvarchar](255) NULL,
	[Departamento] [nvarchar](255) NULL
) ON [PRIMARY]
GO

/****** Object:  Table [FRAUD].[TBL_MN_PFRAU_DIAS] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[FRAUD].[TBL_MN_PFRAU_DIAS]') AND type in (N'U')) DROP TABLE [FRAUD].[TBL_MN_PFRAU_DIAS]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [FRAUD].[TBL_MN_PFRAU_DIAS](
	[CEDULA] [nvarchar](255) NULL,
	[VALOR] [nvarchar](255) NULL,
	[OBSERVACION_] [nvarchar](255) NULL
) ON [PRIMARY]
GO


/****** Object:  Table [FRAUD].[TBL_MN_PFRAU_DPTO_OCURRENCIA] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[FRAUD].[TBL_MN_PFRAU_DPTO_OCURRENCIA]') AND type in (N'U')) DROP TABLE [FRAUD].[TBL_MN_PFRAU_DPTO_OCURRENCIA]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [FRAUD].[TBL_MN_PFRAU_DPTO_OCURRENCIA](
	[id] [int] NULL,
	[DPTO_OCURRENCIA] [varchar](255) NOT NULL,
	[Cod_Depto_Ocurrencia] [int] NULL,
	[fecha_creacion] [datetime] NULL,
	[fecha_act] [datetime] NULL
) ON [PRIMARY]
GO

/****** Object:  Table [FRAUD].[TBL_MN_PFRAU_DPTO_RECLAMANTE] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[FRAUD].[TBL_MN_PFRAU_DPTO_RECLAMANTE]') AND type in (N'U')) DROP TABLE [FRAUD].[TBL_MN_PFRAU_DPTO_RECLAMANTE]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [FRAUD].[TBL_MN_PFRAU_DPTO_RECLAMANTE](
	[id] [int] NULL,
	[DPTO_RECLAMANTE] [varchar](255) NOT NULL,
	[Cod_Depto_Reclamante] [int] NULL,
	[fecha_creacion] [datetime] NULL,
	[fecha_act] [datetime] NULL
) ON [PRIMARY]
GO

/****** Object:  Table [FRAUD].[TBL_MN_PFRAU_IPSALERTA] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[FRAUD].[TBL_MN_PFRAU_IPSALERTA]') AND type in (N'U')) DROP TABLE [FRAUD].[TBL_MN_PFRAU_IPSALERTA]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [FRAUD].[TBL_MN_PFRAU_IPSALERTA](
	[NIT] [nvarchar](255) NULL,
	[IPS] [nvarchar](255) NULL,
	[PROVEEDOR] [nvarchar](255) NULL,
	[ALERTA] [nvarchar](1000) NULL
) ON [PRIMARY]
GO

/****** Object:  Table [FRAUD].[TBL_MN_PFRAU_IPSALTORIESGO] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[FRAUD].[TBL_MN_PFRAU_IPSALTORIESGO]') AND type in (N'U')) DROP TABLE [FRAUD].[TBL_MN_PFRAU_IPSALTORIESGO]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [FRAUD].[TBL_MN_PFRAU_IPSALTORIESGO](
	[Etiquetas de fila] [nvarchar](255) NULL,
	[Suma de Gross] [nvarchar](255) NULL,
	[Casos analizados] [nvarchar](255) NULL,
	[Casos positivos] [nvarchar](255) NULL,
	[Enviar] [nvarchar](255) NULL
) ON [PRIMARY]
GO

/****** Object:  Table [FRAUD].[TBL_MN_PFRAU_LLAMADASAUDITORIA] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[FRAUD].[TBL_MN_PFRAU_LLAMADASAUDITORIA]') AND type in (N'U')) DROP TABLE [FRAUD].[TBL_MN_PFRAU_LLAMADASAUDITORIA]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [FRAUD].[TBL_MN_PFRAU_LLAMADASAUDITORIA](
	[RECLAMACION] [nvarchar](255) NULL,
	[SINIESTRO] [nvarchar](255) NULL,
	[POLIZA] [nvarchar](255) NULL
) ON [PRIMARY]
GO

/****** Object:  Table [FRAUD].[TBL_MN_PFRAU_MPIO_OCURRENCIA] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[FRAUD].[TBL_MN_PFRAU_MPIO_OCURRENCIA]') AND type in (N'U')) DROP TABLE [FRAUD].[TBL_MN_PFRAU_MPIO_OCURRENCIA]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [FRAUD].[TBL_MN_PFRAU_MPIO_OCURRENCIA](
	[id] [int] NULL,
	[CIUDAD_OCURRENCIA] [varchar](255) NOT NULL,
	[Cod_ciudad_Ocurrencia] [int] NULL,
	[fecha_creacion] [datetime] NULL,
	[fecha_act] [datetime] NULL
) ON [PRIMARY]
GO

/****** Object:  Table [FRAUD].[TBL_MN_PFRAU_MPIO_RECLAMANTE] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[FRAUD].[TBL_MN_PFRAU_MPIO_RECLAMANTE]') AND type in (N'U')) DROP TABLE [FRAUD].[TBL_MN_PFRAU_MPIO_RECLAMANTE]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [FRAUD].[TBL_MN_PFRAU_MPIO_RECLAMANTE](
	[id] [int] NULL,
	[CIUDAD_RECLAMANTE] [varchar](255) NOT NULL,
	[Cod_ciudad_Reclamante] [int] NULL,
	[fecha_creacion] [datetime] NULL,
	[fecha_act] [datetime] NULL
) ON [PRIMARY]
GO

/****** Object:  Table [FRAUD].[TBL_MN_PFRAU_NIT_RECLAMANTE] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[FRAUD].[TBL_MN_PFRAU_NIT_RECLAMANTE]') AND type in (N'U')) DROP TABLE [FRAUD].[TBL_MN_PFRAU_NIT_RECLAMANTE]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [FRAUD].[TBL_MN_PFRAU_NIT_RECLAMANTE](
	[id] [int] NULL,
	[NIT_RECLAMANTE] [varchar](255) NOT NULL,
	[NITReclamante] [varchar](255) NULL,
	[fecha_creacion] [datetime] NULL,
	[fecha_act] [datetime] NULL
) ON [PRIMARY]
GO

/****** Object:  Table [FRAUD].[TBL_MN_PFRAU_PLACAS] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[FRAUD].[TBL_MN_PFRAU_PLACAS]') AND type in (N'U')) DROP TABLE [FRAUD].[TBL_MN_PFRAU_PLACAS]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [FRAUD].[TBL_MN_PFRAU_PLACAS](
	[PLACA] [nvarchar](255) NULL,
	[VALOR] [nvarchar](255) NULL,
	[VALOR_B] [nvarchar](255) NULL,
	[OBSERVACION_] [nvarchar](255) NULL
) ON [PRIMARY]
GO

/****** Object:  Table [FRAUD].[TBL_MN_PFRAU_PARAMETROS_PRUEBA]    Script Date: 8/03/2022 3:50:12 p.�m. ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[FRAUD].[TBL_MN_PFRAU_PARAMETROS_PRUEBA]') AND type in (N'U')) DROP TABLE [FRAUD].[TBL_MN_PFRAU_PARAMETROS_PRUEBA]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [FRAUD].[TBL_MN_PFRAU_PARAMETROS_PRUEBA](
	[ID_PARAMETRO] [int] IDENTITY(1,1) NOT NULL,
	[NOM_PARAMETRO] [nvarchar](50) NOT NULL,
	[VAL_PARAMETRO] [nvarchar](max) NULL,
	[PROCESO] [nvarchar](50) NOT NULL,
	[PROYECTO] [nvarchar](50) NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

/****** Object:  Table [FRAUD].[TBL_LOG_PFRAU_CARGA]    Script Date: 9/03/2022 9:27:34 a. m. ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[FRAUD].[TBL_LOG_PFRAU_CARGA]') AND type in (N'U')) DROP TABLE [FRAUD].[TBL_LOG_PFRAU_CARGA]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [FRAUD].[TBL_LOG_PFRAU_CARGA](
	[ID_LOG] [int] IDENTITY(1,1) NOT NULL,
	[NUM_TAREA] [smallint] NOT NULL,
	[NOM_TAREA] [varchar](250) NULL,
	[NOM_PROCESO] [nvarchar](50) NOT NULL,
	[FECHA_EJECUCION] [datetime] NOT NULL,
	[OBJETO_PY] [nvarchar](250) NULL,
	[OBJETO_BD] [nvarchar](250) NULL,
	[FALLO] [nvarchar](10) NOT NULL,
	[DESCRIPCION] [varchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

/* *************************************************************** */
/*               CREACI�N TABLAS ESQUEMA STAGE                     */
/* *************************************************************** */

/****** Object:  Table [STAGE].[STG_MN_PFRAU_ACTCORTE] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[STAGE].[STG_MN_PFRAU_ACTCORTE]') AND type in (N'U')) DROP TABLE [STAGE].[STG_MN_PFRAU_ACTCORTE]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [STAGE].[STG_MN_PFRAU_ACTCORTE](
	[TIPO] [nvarchar](255) NULL,
	[VALOR] [nvarchar](255) NULL
) ON [PRIMARY]
GO

/****** Object:  Table [STAGE].[STG_MN_PFRAU_CAMBIOESTADO] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[STAGE].[STG_MN_PFRAU_CAMBIOESTADO]') AND type in (N'U')) DROP TABLE [STAGE].[STG_MN_PFRAU_CAMBIOESTADO]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [STAGE].[STG_MN_PFRAU_CAMBIOESTADO](
	[Observacion] [nvarchar](1000) NULL,
	[Cambio de estad] [nvarchar](255) NULL,
	[NUMERO_SINIESTRO] [nvarchar](255) NULL,
	[NUMERO_RECLAMACION] [nvarchar](255) NULL
) ON [PRIMARY]
GO

/****** Object:  Table [STAGE].[STG_MN_PFRAU_CENSO] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[STAGE].[STG_MN_PFRAU_CENSO]') AND type in (N'U')) DROP TABLE [STAGE].[STG_MN_PFRAU_CENSO]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [STAGE].[STG_MN_PFRAU_CENSO](
	[Poliza+Fecha accidente+Cedula] [nvarchar](255) NULL,
	[ID_CASO_IPS] [nvarchar](255) NULL,
	[REGION] [nvarchar](255) NULL,
	[RESULTADO] [nvarchar](255) NULL,
	[FECHA_ENTREGA] [nvarchar](255) NULL,
	[CAUSAL_NO_COBERTURA] [nvarchar](255) NULL
) ON [PRIMARY]
GO

/****** Object:  Table [STAGE].[STG_MN_PFRAU_CIUDADES] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[STAGE].[STG_MN_PFRAU_CIUDADES]') AND type in (N'U')) DROP TABLE [STAGE].[STG_MN_PFRAU_CIUDADES]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [STAGE].[STG_MN_PFRAU_CIUDADES](
	[Ciudades] [nvarchar](255) NULL,
	[Departamento] [nvarchar](255) NULL
) ON [PRIMARY]
GO

/****** Object:  Table [STAGE].[STG_MN_PFRAU_DIAS] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[STAGE].[STG_MN_PFRAU_DIAS]') AND type in (N'U')) DROP TABLE [STAGE].[STG_MN_PFRAU_DIAS]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [STAGE].[STG_MN_PFRAU_DIAS](
	[CEDULA] [nvarchar](255) NULL,
	[VALOR] [nvarchar](255) NULL,
	[OBSERVACION_] [nvarchar](255) NULL
) ON [PRIMARY]
GO

/****** Object:  Table [STAGE].[STG_MN_PFRAU_DPTO_OCURRENCIA] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[STAGE].[STG_MN_PFRAU_DPTO_OCURRENCIA]') AND type in (N'U')) DROP TABLE [STAGE].[STG_MN_PFRAU_DPTO_OCURRENCIA]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [STAGE].[STG_MN_PFRAU_DPTO_OCURRENCIA](
	[ID] [numeric](20, 0) NULL,
	[DPTO_OCURRENCIA] [varchar](255) NULL,
	[Cod_Depto_Ocurrencia] [numeric](20, 0) NULL
) ON [PRIMARY]
GO

/****** Object:  Table [STAGE].[STG_MN_PFRAU_DPTO_RECLAMANTE] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[STAGE].[STG_MN_PFRAU_DPTO_RECLAMANTE]') AND type in (N'U')) DROP TABLE [STAGE].[STG_MN_PFRAU_DPTO_RECLAMANTE]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [STAGE].[STG_MN_PFRAU_DPTO_RECLAMANTE](
	[ID] [numeric](20, 0) NULL,
	[DPTO_RECLAMANTE] [varchar](255) NULL,
	[Cod_Depto_Reclamante] [numeric](20, 0) NULL
) ON [PRIMARY]
GO

/****** Object:  Table [STAGE].[STG_MN_PFRAU_IPSALERTA] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[STAGE].[STG_MN_PFRAU_IPSALERTA]') AND type in (N'U')) DROP TABLE [STAGE].[STG_MN_PFRAU_IPSALERTA]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [STAGE].[STG_MN_PFRAU_IPSALERTA](
	[NIT] [nvarchar](255) NULL,
	[IPS] [nvarchar](255) NULL,
	[PROVEEDOR] [nvarchar](255) NULL,
	[ALERTA] [nvarchar](1000) NULL
) ON [PRIMARY]
GO

/****** Object:  Table [STAGE].[STG_MN_PFRAU_IPSALTORIESGO] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[STAGE].[STG_MN_PFRAU_IPSALTORIESGO]') AND type in (N'U')) DROP TABLE [STAGE].[STG_MN_PFRAU_IPSALTORIESGO]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [STAGE].[STG_MN_PFRAU_IPSALTORIESGO](
	[Etiquetas de fila] [nvarchar](255) NULL,
	[Suma de Gross] [nvarchar](255) NULL,
	[Casos analizados] [nvarchar](255) NULL,
	[Casos positivos] [nvarchar](255) NULL,
	[Enviar] [nvarchar](255) NULL
) ON [PRIMARY]
GO

/****** Object:  Table [STAGE].[STG_MN_PFRAU_LLAMADASAUDITORIA] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[STAGE].[STG_MN_PFRAU_LLAMADASAUDITORIA]') AND type in (N'U')) DROP TABLE [STAGE].[STG_MN_PFRAU_LLAMADASAUDITORIA]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [STAGE].[STG_MN_PFRAU_LLAMADASAUDITORIA](
	[RECLAMACION] [nvarchar](255) NULL,
	[SINIESTRO] [nvarchar](255) NULL,
	[POLIZA] [nvarchar](255) NULL
) ON [PRIMARY]
GO

/****** Object:  Table [STAGE].[STG_MN_PFRAU_MPIO_OCURRENCIA] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[STAGE].[STG_MN_PFRAU_MPIO_OCURRENCIA]') AND type in (N'U')) DROP TABLE [STAGE].[STG_MN_PFRAU_MPIO_OCURRENCIA]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [STAGE].[STG_MN_PFRAU_MPIO_OCURRENCIA](
	[ID] [numeric](20, 0) NULL,
	[CIUDAD_OCURRENCIA] [varchar](255) NULL,
	[Cod_ciudad_Ocurrencia] [numeric](20, 0) NULL
) ON [PRIMARY]
GO

/****** Object:  Table [STAGE].[STG_MN_PFRAU_MPIO_RECLAMANTE] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[STAGE].[STG_MN_PFRAU_MPIO_RECLAMANTE]') AND type in (N'U')) DROP TABLE [STAGE].[STG_MN_PFRAU_MPIO_RECLAMANTE]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [STAGE].[STG_MN_PFRAU_MPIO_RECLAMANTE](
	[ID] [numeric](20, 0) NULL,
	[CIUDAD_RECLAMANTE] [varchar](255) NULL,
	[Cod_ciudad_Reclamante] [numeric](20, 0) NULL
) ON [PRIMARY]
GO

/****** Object:  Table [STAGE].[STG_MN_PFRAU_NIT_RECLAMANTE] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[STAGE].[STG_MN_PFRAU_NIT_RECLAMANTE]') AND type in (N'U')) DROP TABLE [STAGE].[STG_MN_PFRAU_NIT_RECLAMANTE]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [STAGE].[STG_MN_PFRAU_NIT_RECLAMANTE](
	[ID] [numeric](20, 0) NULL,
	[NIT_RECLAMANTE] [varchar](255) NULL,
	[NITReclamante] [numeric](20, 0) NULL
) ON [PRIMARY]
GO

/****** Object:  Table [STAGE].[STG_MN_PFRAU_PLACAS] ******/
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[STAGE].[STG_MN_PFRAU_PLACAS]') AND type in (N'U')) DROP TABLE [STAGE].[STG_MN_PFRAU_PLACAS]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [STAGE].[STG_MN_PFRAU_PLACAS](
	[PLACA] [nvarchar](255) NULL,
	[VALOR] [nvarchar](255) NULL,
	[VALOR_B] [nvarchar](255) NULL,
	[OBSERVACION_] [nvarchar](255) NULL
) ON [PRIMARY]
GO

/* *************************************************************** */
/*                    CREACI�N DE COLUMNAS                         */
/* *************************************************************** */

USE SIT_MINERIA
GO

/****** Object:  Table [STAGE].[STG_MN_PFRAU_RECLAMACION] ******/

IF NOT EXISTS(SELECT 1 FROM sys.columns WHERE (Name = N'LIQ_AUTOMATICA' OR name=N'PROC_JURIDICO') AND Object_ID = Object_ID(N'[STAGE].[STG_MN_PFRAU_RECLAMACION]'))
BEGIN
       ALTER TABLE [STAGE].[STG_MN_PFRAU_RECLAMACION]
	   ADD LIQ_AUTOMATICA VARCHAR (100) NULL,
	   PROC_JURIDICO VARCHAR (100) NULL
END
GO


/* *************************************************************** */
/*                  CREACI�N STORED PROCEDURES                     */
/* *************************************************************** */

USE [SIT_MINERIA]
GO

/****** Object:  StoredProcedure [FRAUD].[getParameter]    Script Date: 8/03/2022 3:44:03 p.�m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [FRAUD].[getParameter]
	@proceso as varchar(50),
	@nom_parametro as varchar(50)
AS
BEGIN
	SET NOCOUNT ON;
	SELECT REPLACE(VAL_PARAMETRO,'%FechaSistema%',FORMAT(getdate(), 'yyyyMMdd')) as VAL_PARAMETRO
	FROM [FRAUD].[TBL_MN_PFRAU_PARAMETROS_PRUEBA]
	WHERE PROCESO = @proceso AND NOM_PARAMETRO = @nom_parametro
END
GO

/****** Object:  StoredProcedure [FRAUD].[saveCargaLog]    Script Date: 8/03/2022 3:45:35 p.�m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [FRAUD].[saveCargaLog]
	@NUM_TAREA smallint,
	@NOM_TAREA varchar(250),
	@NOM_PROCESO nvarchar(50),
	--@FECHA_EJECUCION datetime,
	@OBJETO_PY nvarchar(250),
	@OBJETO_BD nvarchar(250),
	@FALLO nvarchar(10),
	@DESCRIPCION varchar(MAX)

AS
BEGIN
	SET NOCOUNT ON;
	 INSERT INTO [FRAUD].[TBL_LOG_PFRAU_CARGA](NUM_TAREA, NOM_TAREA, NOM_PROCESO, FECHA_EJECUCION, OBJETO_PY, OBJETO_BD, FALLO, DESCRIPCION) VALUES (@NUM_TAREA, @NOM_TAREA, @NOM_PROCESO, GETDATE(), @OBJETO_PY, @OBJETO_BD, @FALLO, @DESCRIPCION)

END
GO





