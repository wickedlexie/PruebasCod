from enum import Enum


class ErrorCategory(Enum):
    Technical = "Error Tecnico"
    Business = "Error Negocio"
    Other = "Otro Error"
