from pandas.core.frame import DataFrame
from src.domain.response.mailSendResponse import MailSendResponse
from src.domain.response.ssisParametersResponse import SsisParametersResponse
from src.domain.response.fileParametersResponse import FileParametersResponse
from src.clean.cleanMain import DataCleaning
from src.data.repository.ssisRepository import SSISRepository
from src.dataStorage.fileManagement import FileManagement
from src.agentservices.mail.mailParametersDB import MailParametersDb
from src.agentservices.mail.mailManagement import MailManagement
from src.agentservices.mail.mailParametersjson import MailParametersJson
from src.infraestructure.log.loggingHandler import LoggingHandler
from src.infraestructure.log.logCodification import LogCodification
from src.data.repository.processesRepository import ProcessesRepository
from src.domain.response.globalParametersResponse import GlobalParametersResponse
from src.data.repository.fileParametersRepository import FileParametersRepository
from src.dataStorage.moveFile import MoveFile
from src.train.Score import Model
from src.train.Automatizacion import Automatizacion
from src.dataStorage.cleanFolder import CleanFolder
import os.path
import glob