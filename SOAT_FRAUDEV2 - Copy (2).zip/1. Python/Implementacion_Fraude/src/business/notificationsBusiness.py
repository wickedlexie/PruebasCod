from pandas.core.frame import DataFrame

class impLog():
    def printLog():
        data = {'Prueba': ['EJECUTANDO IMPLOG']}
        data= DataFrame(data)
        data.to_csv('D:\PRUEBA\logIMPLOG.csv', index=None)