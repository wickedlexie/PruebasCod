from enum import Enum

class GlobalParametersRequest(Enum):
    globalProcess = 'ARCHIVOS_PARAMETROS'
    processes = 'ARCHIVOS_PARAMETROS' #Aqui se debe colocar el parámetro que tiene la lista de procesos que se usaran