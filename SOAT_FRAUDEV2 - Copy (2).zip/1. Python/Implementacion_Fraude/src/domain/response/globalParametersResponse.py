from pydantic import BaseModel

class GlobalParametersResponse (BaseModel):
    processes : str