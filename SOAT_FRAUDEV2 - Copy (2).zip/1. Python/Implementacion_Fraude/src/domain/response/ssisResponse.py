from pydantic import BaseModel

class SsisResponse (BaseModel):
    result : str